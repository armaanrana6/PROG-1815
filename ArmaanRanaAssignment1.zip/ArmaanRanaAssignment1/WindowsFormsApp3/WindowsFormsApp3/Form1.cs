﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[,] seats = new string[5, 3];

        
//-----------------------------------------------STATUS-------------------------------------------------------------------------
        private void button17_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                if (seats[0, 0] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                if (seats[0, 1] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                if (seats[0, 2] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                if (seats[1, 0] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                if (seats[1, 1] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                if (seats[0, 1] == "")
                {
                    textBox2.Text = "available";
                }
                else
                {
                    textBox2.Text = "not available";
                }
            }

        }
//--------------------------------------------BOOK----------------------------------------------------
        private void button18_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            if(text=="")
            {
                MessageBox.Show("Please enter name");
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seats[0, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seats[0, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seats[0, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seats[1, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seats[1, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seats[1, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seats[2, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seats[2, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seats[2, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seats[3, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seats[3, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seats[3, 2] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seats[4, 0] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seats[4, 1] = textBox1.Text;
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seats[4, 2] = textBox1.Text;
            }


        }

        //------------------------------------SHOW-ALL--------------------------------------------------
        private void button16_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            richTextBox1.Text = richTextBox1.Text += seats[0, 0] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[0, 1] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[0, 2] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[1, 0] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[1, 1] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[1, 2] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[2, 0] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[2, 1] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[2, 2] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[3, 0] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[3, 1] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[3, 2] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[4, 0] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[4, 1] + "\n";
            richTextBox1.Text = richTextBox1.Text += seats[4, 2] + "\n";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //----------ADD-WAITING-LIST-----------------------
        private void button20_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            richTextBox2.Text = text.ToString();
        }
        //-----------------------SHOW-WAITING-LIST------------------------------
        private void button21_Click(object sender, EventArgs e)
        {
            richTextBox2.Refresh();
        }

        //--------------------------------CANCEL----------------------------------------------------
        private void button19_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                seats[0, 0] = "";
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                seats[0, 1] = "";
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                seats[0, 2] = "";
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                seats[1, 0] = "";
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                seats[1, 1] = "";
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                seats[1, 2] = "";

            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                seats[2, 0] = "";
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                seats[2, 1] = "";
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                seats[2, 2] = "";
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                seats[3, 0] = "";
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                seats[3, 1] = "";
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                seats[3, 2] = "";
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                seats[4, 0] = "";
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                seats[4, 1] = "";
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                seats[4, 2] = "";
            }

        }
        //----------------------------------------FILL-ALL---------------------------------------------
        private void button22_Click(object sender, EventArgs e)
        {
            seats[0, 0] = "armaan";
            seats[0, 1] = "armaan";
            seats[0, 2] = "armaan";
            seats[1, 0] = "armaan";
            seats[1, 1] = "armaan";
            seats[1, 2] = "armaan";
            seats[2, 0] = "armaan";
            seats[2, 1] = "armaan";
            seats[2, 2] = "armaan";
            seats[3, 0] = "armaan";
            seats[3, 1] = "armaan";
            seats[3, 2] = "armaan";
            seats[4, 0] = "armaan";
            seats[4, 1] = "armaan";
            seats[4, 2] = "armaan";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

