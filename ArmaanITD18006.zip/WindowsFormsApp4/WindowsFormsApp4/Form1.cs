﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                StreamWriter obj = new StreamWriter("ct.txt", true);
                String tr = textBox2.Text;
                String dt = textBox3.Text;
                String sn = textBox4.Text;
                String tp = textBox5.Text;
                String pr = textBox6.Text;
                String qt = textBox7.Text;
                String am = textBox8.Text;
                obj.WriteLine(tr+","+dt+ "," + sn+ "," + tp+ "," + pr+ "," + qt+ "," + am);
                
                obj.Close();
                MessageBox.Show("Data Saved");
            }
            else if (radioButton2.Checked)
            {
                string file;
                OpenFileDialog obj1 = new OpenFileDialog();
                obj1.InitialDirectory = Directory.GetCurrentDirectory();
                if (obj1.ShowDialog() == DialogResult.OK)
                {

                    file = obj1.FileName;
                    label1.Text = "";
                    StreamReader reading = new StreamReader(file);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string delimiter = ",";
            string tablename = "AudioTable";
            DataSet dataset = new DataSet();

            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "All Files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                
      
                    string filename = openFileDialog1.FileName;
                    StreamReader sr = new StreamReader(filename);
                    string csv = File.ReadAllText(openFileDialog1.FileName);
                    dataset.Tables.Add(tablename);
                    dataset.Tables[tablename].Columns.Add("#");
                    dataset.Tables[tablename].Columns.Add("Purchase-Date");
                    dataset.Tables[tablename].Columns.Add("Serial #");
                    dataset.Tables[tablename].Columns.Add("Manufacturing");
                    dataset.Tables[tablename].Columns.Add("Price");
                    dataset.Tables[tablename].Columns.Add("Qty");
                    dataset.Tables[tablename].Columns.Add("Amount");


                    string allData = sr.ReadToEnd();
                    string[] rows = allData.Split("\r".ToCharArray());

                    foreach (string r in rows)
                    {
                        string[] items = r.Split(delimiter.ToCharArray());
                        dataset.Tables[tablename].Rows.Add(items);
                    }
                    this.dataGridView1.DataSource = dataset.Tables[0].DefaultView;
                    
                }

            }
        }
          
            


        }
    
    
    
